const nombre = "Yirsis";
const edad = new Date().getFullYear() - 2000;

const mensaje = `Bienvenido ${nombre}, tienes la edad de ${edad}`;

document.write(mensaje);
