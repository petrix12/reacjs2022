const cuenta = -10;

const mensaje = cuenta < 0 && "Hola";

document.write(mensaje);
