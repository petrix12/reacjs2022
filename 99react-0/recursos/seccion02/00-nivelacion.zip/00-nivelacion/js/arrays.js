const [, usario2, ,] = ["Pepe", "Juan", "Lucia", "Maria"];

document.write(usario2);

// const numeros = [1, 2, 3, 4];
// document.write("<ul>");
// numeros.map((numero) => numero + 1);
// document.write("</ul>");
// document.write(numeros);
// document.write(nuevo);
