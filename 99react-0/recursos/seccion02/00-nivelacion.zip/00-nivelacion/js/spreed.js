const frutas = ["manzana", "uva", "melon"];
const citricos = ["naranja", "limon", "toronja"];

const nuevo = [...frutas, ...citricos];

document.write(nuevo);
