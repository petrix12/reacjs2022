const nombre = "Yirsis";

document.write(nombre);
