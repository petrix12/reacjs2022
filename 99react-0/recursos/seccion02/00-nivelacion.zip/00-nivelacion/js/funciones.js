const sumar = (a, b) => a + b;

const resultado = sumar(5, 3);

document.write(resultado);
